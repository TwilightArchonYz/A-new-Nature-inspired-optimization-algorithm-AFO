function [bestY,bestX,recording]=PSO(x,y,option,data)
    %% PSO算法
    %% 初始化
    recording.bestFit=zeros(option.maxIteration+1,1);
    recording.meanFit=zeros(option.maxIteration+1,1);
    v=randn(size(x));
    %% 更新记录
    [y_g,position]=min(y);
    x_g=x(position(1),:);
    y_p=y;
    x_p=x;
    recording.bestFit=y_g;
    recording.meanFit=mean(y_p);
    %% 开始更新
    for iter=1:option.maxIteration
        disp(['GAPSO,iter:',num2str(iter),',minFit:',num2str(y_g)])
        %% 更新
        for i=1:option.numAgent
            v(i,:)=option.w_pso*v(i,:)+option.c1_pso*rand(1,option.dim).*(x_g-x(i,:))+option.c2_pso*rand(1,option.dim).*(x_p(i,:)-x(i,:));
            x(i,:)=x(i,:)+v(i,:);
            x(i,:)=checkX(x(i,:),option,data);
            y(i)=option.fobj(x(i,:),option,data);
            if y(i)<y_p(i)
                y_p(i)=y(i);
                x_p(i,:)=x(i,:);
                if y_p(i)<y_g
                    y_g=y_p(i);
                    x_g=x_p(i,:);
                end
            end
        end
        %% 竞标赛法选择个体
        for i=1:option.numAgent*2
            maxContestants=ceil(randi(option.numAgent));
            index=randperm(option.numAgent,maxContestants);
            [~,position]=min(y(index));
            parent(i)=index(position(1));
        end
        newX=x*0;
        newY=y*0;
        %% 交叉(多点交叉)
        for i=1:option.numAgent
            newX(i,:)=x(parent(i),:);
            r1=randi(option.numAgent);
            r2=randi(option.numAgent); 
            newX(i,:)=newX(i,:)+rand(1,option.dim).*(x(r1,:)-x(r2,:));
        end
        %% 重新计算适应度值
        for i=1:option.numAgent
            newX(i,:)=checkX(newX(i,:),option,data);
            [newY(i),~,newX(i,:)]=option.fobj(newX(i,:),option,data);
            if newY(i)<y_p(i)
                y_p(i)=newY(i);
                x_p(i,:)=newX(i,:);
                if y_p(i)<y_g
                    y_g=y_p(i);
                    x_g=x_p(i,:);
                end
            end
        end
        %% 更新记录
        recording.bestFit(1+iter)=y_g;
        recording.meanFit(1+iter)=mean(y_p);
    end
    bestY=y_g;
    bestX=x_g;
end