function [bestY,bestX,recording]=myIGWO(x,y,option,data)
    %% GWO�㷨
    SearchAgents_no=option.numAgent;
    Max_iter=option.maxIteration;
    lb=option.lb;
    ub=option.ub;
    dim=option.dim;
    fobj=option.fobj;
    %[Leader_score,Leader_pos,Convergence_curve]=EHO(x,SearchAgents_no,Max_iter,lb,ub,dim,fobj);
    [Alpha_score,Alpha_pos,Convergence_curve]=IGWO(x,SearchAgents_no,Max_iter,lb,ub,dim,fobj);
    %% ��ʼ��
    recording.bestFit=[min(y),Convergence_curve]';
    recording.meanFit=zeros(option.maxIteration+1,1);
    bestY=Alpha_score;
    bestX=Alpha_pos;
end