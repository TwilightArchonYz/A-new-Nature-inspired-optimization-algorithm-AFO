function [bestY,bestX,recording]=PSO(x,y,option,data)
    %% PSO�㷨
    
    %% ��ʼ��
    recording.bestFit=zeros(option.maxIteration+1,1);
    recording.meanFit=zeros(option.maxIteration+1,1);
    v=randn(size(x));
    %% ���¼�¼
    [y_g,position]=min(y);
    x_g=x(position(1),:);
    y_p=y;
    x_p=x;
    recording.bestFit=y_g;
    recording.meanFit=mean(y_p);
    %% ��ʼ����
    for iter=1:option.maxIteration
        disp(['PSO,iter:',num2str(iter),',minFit:',num2str(y_g)])
        %% ����
        for i=1:option.numAgent
            v(i,:)=option.w_pso*v(i,:)+option.c1_pso*rand(size(x(1,:))).*(x_g-x(i,:))+option.c2_pso*rand(size(x(1,:))).*(x_p(i,:)-x(i,:));
            x(i,:)=x(i,:)+v(i,:);
            x(i,:)=checkX(x(i,:),option,data);
            [y(i),~,x(i,:)]=option.fobj(x(i,:),option,data);
            if y(i)<y_p(i)
                y_p(i)=y(i);
                x_p(i,:)=x(i,:);
                if y_p(i)<y_g
                    y_g=y_p(i);
                    x_g=x_p(i,:);
                end
            end
        end
        %% ���¼�¼
        recording.bestFit(1+iter)=y_g;
        recording.meanFit(1+iter)=mean(y_p);
    end
    bestY=y_g;
    bestX=x_g;
end