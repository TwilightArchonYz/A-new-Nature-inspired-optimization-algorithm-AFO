function [bestY,bestX,recording]=GA(x,y,option,data)
    %% �Ŵ��㷨
    %% ��ʼ��
    recording.bestFit=zeros(option.maxIteration+1,1);
    recording.meanFit=zeros(option.maxIteration+1,1);
    %% ���¼�¼
    [y_g,position]=min(y);
    x_g=x(position(1),:);
    y_p=y;
    x_p=x;
    recording.bestFit=y_g;
    recording.meanFit=mean(y_p);
    xList=x;
    %% ��ʼ����
    for iter=1:option.maxIteration
        disp(['GA,iter:',num2str(iter),',minFit:',num2str(y_g)])
        if iter==1
            newX=x*0;
            newY=y;
        end
        %% ��������ѡ�����
        for i=1:option.numAgent*2
            maxContestants=ceil(randi(option.numAgent));
            index=randperm(option.numAgent,maxContestants);
            [~,position]=min(y(index));
            parent(i)=index(position(1));
        end
        newX=x*0;
        newY=y*0;
        %% ����(��㽻��)
        for i=1:option.numAgent
            tempR=rand(size(x(i,:)));
            newX(i,:)=x(parent(i),:);
            newX(i,tempR>0.5)=x(parent(i+option.numAgent),tempR>0.5);
        end
        %% ����
        for i=1:ceil(option.numAgent*option.p2_GA*(1+iter/option.maxIteration))
            index=randi(option.numAgent);
            if rand<0.5
                newX(index,randi(option.dim))=rand;
            else
                index1=randperm(option.dim,2);
                newX(index,index1)=newX(index,index1(end:-1:1));
            end
        end
        %% ���¼�����Ӧ��ֵ
        for i=1:option.numAgent
            while  ismember(newX(i,:),xList,'rows')
                if rand<0.5
                    newX(i,randi(option.dim))=rand;
                else
                    index1=randperm(option.dim,2);
                    newX(i,index1)=newX(i,index1(end:-1:1));
                end
            end
            newX(i,:)=checkX(newX(i,:),option,data);
            [newY(i),~,newX(i,:)]=option.fobj(newX(i,:),option,data);
            if newY(i)<y_p(i)
                y_p(i)=newY(i);
                x_p(i,:)=newX(i,:);
                if y_p(i)<y_g
                    y_g=y_p(i);
                    x_g=x_p(i,:);
                end
            end
        end
        xList=[unique(xList,'rows');x];
        if length(xList(:,1))>=option.lenTS
            xList(option.lenTS+1:end,:)=[];
        end
        x=x_p;
        %% ���¼�¼
        recording.bestFit(1+iter)=y_g;
        recording.meanFit(1+iter)=mean(y_p);
    end
    bestY=y_g;
    bestX=x_g;
end