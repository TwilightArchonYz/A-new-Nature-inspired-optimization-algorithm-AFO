%% 2021.9.2 ��������ѡַ
% 2021.9.2 Logistics centre site selection issues
%% ����ʹ��ԭʼ�㷨��ֱ�������������ר���ڱ�����ĸ��·�ʽ���Խ�һ����߾���
% This is the direct result of using the original algorithm, 
% adding some specific update methods to this problem can further improve the accuracy
clc;
clear;
close all;
warning off
%% �̶����������
noRNG=1;
rng('default')
rng(noRNG)
%% ��������
[data.node,data.node0,data.node1]=xlsread('�ڵ㾭γ��.xlsx',1);
data.D1=xlsread('�����ڵ㵽��������.xlsx',1);
data.D2=xlsread('�����ڵ㵽���ؾ���.xlsx',1);
data.demand=xlsread('����.xlsx',1);
data.noC=find(data.node(:,3)==1);
data.noD=find(data.node(:,3)<3);
data.noP=find(data.node(:,3)==3);
data.numC=length(data.noC);
data.numD=length(data.noD);
data.numP=length(data.noP);
data.numSelected=6;
for i=1:data.numD
    for j=1:data.numC
        D=distance(data.node(data.noD(i),2),data.node(data.noD(i),1),data.node(data.noC(j),2),data.node(data.noC(j),1));  % distance��matlab help
        pi=3.1415926;
        dx=D*6371*2*pi/360;
        data.D1(i,j)=dx;
        %data.D1(i,j)=norm(data.node(data.noD(i),1:2)-data.node(data.noC(j),1:2));
    end
end
for i=1:data.numC
    for j=1:data.numP
        D=distance(data.node(data.noC(i),2),data.node(data.noC(i),1),data.node(data.noP(j),2),data.node(data.noP(j),1));  % distance��matlab help
        pi=3.1415926;
        dx=D*6371*1000*2*pi/360;
        data.D2(i,j)=dx;
        %data.D2(i,j)=norm(data.node(data.noC(i),1:2)-data.node(data.noP(j),1:2))*1000;
    end
end
data.maxLoad=760; %�������
data.alpha=0.5;
data.ck=245; %���ɱ�
data.ct1=0.19; %����ɱ�1
data.ct2=0.26; %����ɱ�2
data.cb=2.45; %�ɱ�ɱ�
figure
hold on
plot(data.node(data.noC,1),data.node(data.noC,2),'rs','LineWidth',2,...
    'MarkerEdgeColor','k',...
    'MarkerFaceColor','g',...
    'MarkerSize',10)
plot(data.node(data.noD,1),data.node(data.noD,2),'ro','LineWidth',2,...
    'MarkerEdgeColor','k',...
    'MarkerFaceColor','r',...
    'MarkerSize',10)
plot(data.node(data.noP,1),data.node(data.noP,2),'rh','LineWidth',2,...
    'MarkerEdgeColor','k',...
    'MarkerFaceColor','b',...
    'MarkerSize',10)
%% �㷨��������
dim=data.numC+data.numD;
%%
option.dim=dim; %�˸����߱���
lb=0;
ub=1;
option.lb=lb;
option.ub=ub;
if length(option.lb)==1
    option.lb=ones(1,option.dim)*option.lb;
    option.ub=ones(1,option.dim)*option.ub;
end
option.fobj=@aimFcn_1;
%option.fobj0=option.fobj;
option.showIter=0;
%% �㷨�������� Parameters
% ��������
option.numAgent=20;        %��Ⱥ������ size of population
option.maxIteration=20;    %���������� maximum number of interation
% ������㷨
option.v_lb=-(option.ub-option.lb)/4;
option.v_ub=(option.ub-option.lb)/4;
option.w2=0.5; %weight of Moving strategy III
option.w4=1;%weight of Moving strategy III
option.w5=1;%weight of Moving strategy III
option.pe=0.01; % rate to judge Premature convergence
option.gap0=ceil(sqrt(option.maxIteration*2))+1;
option.gapMin=5; % min gap
option.dec=2;    % dec of gap
option.L=10;     % Catastrophe
str_legend=[{'AFO1'},{'AFO2'}];
%% Initialize population individuals (common to control experiment algorithm)
x=ones(option.numAgent,option.dim);
y=ones(option.numAgent,1);
for i=1:option.numAgent
    x(i,:)=rand(size(option.lb)).*(option.ub-option.lb)+option.lb;
    y(i)=option.fobj(x(i,:),option,data);
end
%% ʹ���㷨���
% Based on the same population, solve the selected  functions by using different algorithms
bestX=x;
rng(noRNG)
tic
[bestY(1,:),bestX(1,:),recording(1)]=AFO1(x,y,option,data);
tt(1,1)=toc;
rng(noRNG)
tic
[bestY(2,:),bestX(2,:),recording(2)]=AFO2(x,y,option,data);
tt(1,2)=toc;
%%
figure
hold on
for i=1:length(recording)
    plot(-(recording(i).bestFit),'LineWidth',2)
end
legend(str_legend)
title('fitness curve')

%% ������
data.color=[ 0.9088    0.0875    0.8788
    0.5097    0.5402    0.4341
    0.0462    0.9360    0.4905
    0.1753    0.4868    0.5502
    0.0677    0.9388    0.9625
    0.1905    0.2479    0.5507
    0.5309    0.0690    0.3477
    0.0219    0.9636    0.9013
    0.9846    0.6979    0.1700
    0.0208    0.9444    0.1282
    0.4795    0.4249    0.6089
    0.2570    0.1933    0.0006
    0.8181    0.9768    0.7858
    0.0179    0.1955    0.1252];  %һ����һ����ɫ�� ��ԭɫ��ȡֵ0-1֮��
str='AFO1'
[~,result1]=option.fobj(bestX(1,:),option,data);
drawPC(result1,data,str)
str='AFO2'
[~,result2]=option.fobj(bestX(2,:),option,data);
drawPC(result1,data,str)