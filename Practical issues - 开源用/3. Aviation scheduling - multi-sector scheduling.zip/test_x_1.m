function x=test_x_1(x,option,data)
    x(x>1)=1;
    x(x<0)=0.00001;
end