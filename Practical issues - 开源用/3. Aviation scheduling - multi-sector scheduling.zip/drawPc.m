function drawPc(result1,option,data,str)
    figure
    hold on
    plot(data.xyCity(:,1),data.xyCity(:,2),'o','LineWidth',2,...
        'MarkerEdgeColor','k',...
        'MarkerFaceColor','g',...
        'MarkerSize',10)
    strLegend=[{'����'}];
    for i=1:length(result1.path)
        path=result1.path{i};
        plot(data.xyCity(path,1),data.xyCity(path,2),'LineWidth',2)
        strLegend=[strLegend,{['������',num2str(i)]}];
    end
    legend(strLegend)
    title([str,'��Ŀ�꺯��ֵ��',num2str(result1.fit)])
end