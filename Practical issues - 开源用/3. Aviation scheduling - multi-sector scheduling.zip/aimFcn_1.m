function [fit,result]=aimFcn_1(x,option,data)
    x=reshape(x,data.num_flight,3);
    x(x<0.01)=0.01;
    T=min(data.flight(:,3));
    recording.node=zeros(data.num_flight,data.num_node);  %��¼ÿ�ܷɻ�ͨ���ýڵ��ʱ��
    recording.flight=zeros(data.num_flight,20);     %��¼ÿһ�Һ����״̬   
    recording.route=cell(data.num_Route,1);        %��¼�ú������һ�� �ɻ���λ��
    for i=1:data.num_Route
        recording.route{i}=cell(length(data.Route_type{i,2}),1);
    end
    recording.Section=zeros(1,option.num_Section);  %��¼�����ڷɻ�����
    priority_flihgt=x(:,1);
    while 1
        %% ���ҿɵ��ȷɻ�
        position=find(data.flight(:,3)<=T & recording.flight(:,8)==0);
        [~,position1]=sort(priority_flihgt(position));
        position=position(position1);
        for i=1:length(position)
            % ������
            no_flight=position(i);
            % ��������
            type_flight=data.flight(no_flight,5);
            % �����ٶ�
            v_flight=(data.vehicle(type_flight,2)-data.vehicle(type_flight,3))*x(no_flight,2)+data.vehicle(type_flight,3);
            % ���߱��
            no_route=data.flight(no_flight,2);
            % ����߶�
            height_type=ceil(length(data.Route_type{no_route,2})*x(no_flight,3));
            height_flight=data.Route_type{no_route,2}(height_type);
            temp_route=data.Route_num{no_route}(3:end);
            temp_T0=T;
            biaoji=0;
            total_distance=0;
            % ���ú������зɻ�״̬
            if ~isempty(recording.route{no_route})
                if ~isempty(recording.route{no_route}{height_type})
                    if recording.route{no_route}{height_type}(1)<=option.gap_D
                        continue;
                    end
                end
            end
            % ����ÿ���ڵ�ĵִ�ʱ��
            temp_no=[];
            temp_time=[];
            for ii=1:length(temp_route)
                no_node=temp_route(ii);
                no_Section=data.Point(no_node,4);
                if ii==1
                    if temp_T0-max(recording.node(:,no_node))<option.min_gap(no_node)
                        biaoji=1;
                        break;
                    else
                       % recording.node(no_flight,no_node)=temp_T0;
                    end 
                else
                    no_node0=temp_route(ii-1);
                    temp_distance=norm(data.Point(no_node,:)-data.Point(no_node0,:),2);
                    total_distance=total_distance+temp_distance;
                    temp_T=temp_distance/v_flight;
                    temp_T0=temp_T0+temp_T;
                    if temp_T0-max(recording.node(:,no_node))<option.min_gap(no_node)
                        biaoji=1;
                        break;
                    else
                      %  recording.node(no_flight,no_node)=temp_T0;
                    end
                end
                temp_no=[temp_no,no_node];
                temp_time=[temp_time,temp_T0];
            end
            if no_Section~=0
                if recording.Section(no_Section)>option.total_flight(no_Section)
                    continue;
                end
            end
            if biaoji==1
                continue;
            end
            recording.node(no_flight,temp_no)=temp_time;
            % ��¼����״̬
            recording.flight(no_flight,1)=type_flight; %��������
            recording.flight(no_flight,2)=v_flight;    %�����ٶ�
            recording.flight(no_flight,3)=no_route;     %����·��
            recording.flight(no_flight,4)=height_flight;%����߶�
            recording.flight(no_flight,5)=no_route;     %����·��
            recording.flight(no_flight,6)=0;            %��ǰλ��
            recording.flight(no_flight,7)=total_distance;%�յ�λ��
            recording.flight(no_flight,8)=1;            %����״̬ 1 ���״̬2
            recording.flight(no_flight,9)=T;            %����ʱ��
            recording.flight(no_flight,10)=data.flight(no_flight,3); %����Ԥ��ʱ��
            recording.flight(no_flight,11)=T+total_distance/v_flight; %�뿪����ʱ��
            recording.route{no_route}{height_type}(1)=0;
            recording.route{no_route}{height_type}(2)=no_flight;
        end
        %% ���ҷ���״̬�ķɻ�
        recording.Section=zeros(1,option.num_Section);  %��¼�����ڷɻ�����
        position=find(recording.flight(:,8)==1);
        for i=1:length(position)
            % ������
            no_flight=position(i);
            % ��������
            type_flight=data.flight(no_flight,5);
            % �����ٶ�
            v_flight=(data.vehicle(type_flight,2)-data.vehicle(type_flight,1))*x(no_flight,2)+data.vehicle(type_flight,1);
            % ���߱��
            no_route=data.flight(no_flight,2);
            % ����߶�
            height_type=ceil(length(data.Route_type{no_route,2})*x(no_flight,3));
            height_flight=data.Route_type{no_route,2}(height_type);
            temp_route=data.Route_num{no_route}(3:end);
            % ����λ��
            temp_distance0=recording.flight(no_flight,6)+v_flight*option.T_step;
            recording.flight(no_flight,6)=temp_distance0;
            total_distance=recording.flight(no_flight,7);%�յ�λ��
            if temp_distance0>total_distance %�ɻ� ��ɷ���
                recording.flight(no_flight,8)=2;
                continue;
            end
            temp_D=0;
            node_flight=temp_route(1); 
            % ���ҵ�ǰ�ɻ����ڽڵ�λ��
            for ii=2:length(temp_route)
                no_node=temp_route(ii);
                no_node0=temp_route(ii-1);
                temp_distance=norm(data.Point(no_node,2:3)-data.Point(no_node0,2:3),2);
                if temp_D+temp_distance>=temp_distance0
                    node_flight=temp_route(ii); 
                end
            end
            % �ɻ���������
            no_Section=data.Point(node_flight,4);
            if no_Section~=0
                recording.Section(no_Section)=recording.Section(no_Section)+1;
            end
            if recording.route{no_route}{height_type}(2)==no_flight
                recording.route{no_route}{height_type}(1)=temp_distance0;
            end
        end
        T=T+option.T_step;
        position=find(recording.flight(:,8)~=2);
        if isempty(position)
            break;
        end
    end
    %% 
    fit1=sum(recording.flight(:,9)-recording.flight(:,10));
    fit2=max(recording.flight(:,11));
    fit=sum(data.w.*[fit1,fit2]);
    if nargout>1
        result.recording=recording;
    end
end