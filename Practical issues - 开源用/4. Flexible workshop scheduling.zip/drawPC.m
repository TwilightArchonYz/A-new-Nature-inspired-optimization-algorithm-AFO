function drawPC(result,option,str)
    figure
    for i=1:length(result.recording(:,1))
        noJ=result.recording(i,1);
        noO=result.recording(i,2);
        noM=result.recording(i,3);
        ST=result.recording(i,4);
        T=result.recording(i,5);
        rectangle('Position',[ST,noJ-0.45,T,0.9],'facecolor',option.color(noJ,:));
        text(ST+T/4,noJ,['O',num2str(noO),'M',num2str(noM)],'FontWeight','Bold');
    end
    xlabel('ʱ��')
    ylabel('�������')
    title([str,',�Ż��������Ŀ�꣺',num2str(result.fit)]);
    figure
    for i=1:length(result.recording(:,1))
        noJ=result.recording(i,1);
        noO=result.recording(i,2);
        noM=result.recording(i,3);
        ST=result.recording(i,4);
        T=result.recording(i,5);
        rectangle('Position',[ST,noM-0.45,T,0.9],'facecolor',option.color(noJ,:));
        text(ST+T/4,noM,['O',num2str(noO),'J',num2str(noJ)],'FontWeight','Bold');
    end
    xlabel('ʱ��')
    ylabel('�������')
    title([str,',�Ż��������Ŀ�꣺',num2str(result.fit)]);

end