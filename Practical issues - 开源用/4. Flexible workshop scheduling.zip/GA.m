function [bestY,bestX,recording]=GA(x,y,option,data)
    %% �Ŵ��㷨
    %% ��ʼ��
    recording.bestFit=zeros(option.maxIteration+1,1);
    recording.meanFit=zeros(option.maxIteration+1,1);
    %% ���¼�¼
    [y_g,position]=min(y);
    x_g=x(position(1),:);
    y_p=y;
    x_p=x;
    recording.bestFit=y_g;
    recording.meanFit=mean(y_p);
    %% ��ʼ����
    for iter=1:option.maxIteration
        %disp(['GA,iter:',num2str(iter),',minFit:',num2str(y_g)])
        %% ��������ѡ�����
        for i=1:option.numAgent*2
            maxContestants=ceil(randi(option.numAgent)*option.p1_GA);
            index=randperm(option.numAgent,maxContestants);
            [~,position]=min(y(index));
            parent(i)=index(position(1));
        end
        newX=x*0;
        newY=y*0;
        %% ����(��㽻��)
        for i=1:option.numAgent
            tempR=rand(size(x(i,:)));
            newX(i,:)=x(parent(i),:);
            newX(i,tempR>0.5)=x(parent(i+option.numAgent),tempR>0.5);
        end
        %% ����
        for i=1:option.numAgent*option.p2_GA
            index=randi(option.numAgent);
            tempR=rand(size(x(i,:)));
            temp=rand(size(option.lb)).*(option.ub-option.lb)+option.lb;
            newX(i,tempR>0.5)=temp(tempR>0.5);
        end
        %% ���¼�����Ӧ��ֵ
        for i=1:option.numAgent
            newX(i,:)=checkX(newX(i,:),option,data);
            newY(i)=option.fobj(newX(i,:),option,data);
            if newY(i)<y_p(i)
                y_p(i)=newY(i);
                x_p(i,:)=newX(i,:);
                if y_p(i)<y_g
                    y_g=y_p(i);
                    x_g=x_p(i,:);
                end
            end
        end
        %% ���¼�¼
        recording.bestFit(1+iter)=y_g;
        recording.meanFit(1+iter)=mean(y_p);
    end
    bestY=y_g;
    bestX=x_g;
end