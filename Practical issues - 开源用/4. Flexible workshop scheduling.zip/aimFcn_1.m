function [fit,result]=aimFcn_1(x,option,data)
    global option data
    x=reshape(x,data.numP,data.numM);
    MT=zeros(1,data.numM); %ÿ��������ǰ����������ʱ��
    PT=zeros(1,data.numP); %ÿ��������ɵ�ʱ��
    flag=zeros(1,data.numP); %ÿ�������Ƿ����
    PJ=ones(1,data.numJ); %ÿ�������ĵ�ǰ����
    recording=[];
    while sum(flag)~=data.numP
        %���ҵ�ǰ�ɿ����Ĺ�����
        for noJ=1:data.numJ
            noP=PJ(noJ);
            position=find(data.Process(:,1)==noJ & data.Process(:,2)==noP);
            if isempty(position)
                tempMT(noJ,:)=inf;
                tempPri(noJ,:)=inf;
                tempPri1(noJ,:)=inf;
                tempPri2(noJ,:)=inf;
            else
                tempMT(noJ,:)=data.Process(position,3:end);
                tempPri(noJ,:)=x(position,:);
                tempPri1(noJ,:)=data.lambda_gama(position,2:end);
                tempPri2(noJ,:)=repmat(data.lambda_gama(position,1),1,data.numM);
            end
            tempST(noJ,:)=MT+1;
        end
        temp=tempMT.*tempPri.*tempST./tempPri1./tempPri2;
        [p1,p2]=find(temp==min(min(temp)));
        noJ=p1(1);
        noM=p2(1);
        noP=PJ(noJ);
        position=find(data.Process(:,1)==noJ & data.Process(:,2)==noP);
        if noP==1
            ST=0;
        else
            position1=find(data.Process(:,1)==noJ & data.Process(:,2)==noP-1);
            ST=PT(position1);
        end
        ST=max(ST,MT(noM));
        T=data.Process(position,2+noM);
        MT(noM)=ST+T;
        PJ(noJ)=PJ(noJ)+1;
        flag(position)=1;
        PT(position)=ST+T;
        lambda=data.Process(position,1);
        gama=data.Process(position,1+noM);
        recording=[recording;noJ,noP,noM,ST,T,ST+T,lambda,gama];
    end
    fit=-data.Z*sum(recording(:,7).*recording(:,8)./recording(:,5));
    if nargout>1
        result.fit=-fit;
        result.recording=recording;
    end
end