function drawPc1(result1,option,data,str)
% ������
q=result1.q;
for i=1:3
    q(:,i) = smoothdata(q(:,i),1);
end

figure
subplot(3,1,1); plot(q(:,1)); xlabel('t'); ylabel('Joint 1 (rad)');
subplot(3,1,2); plot(q(:,2)); xlabel('t'); ylabel('Joint 2 (rad)');
subplot(3,1,3); plot(q(:,3)); xlabel('t'); ylabel('Joint 3 (rad)');
sgtitle([str,'�Ż����,��ʱ�䣺',num2str(result1.fit)])
end