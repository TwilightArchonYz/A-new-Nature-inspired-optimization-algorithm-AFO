function [fit,result,x0]=aimFcn_1(x,option,data)
    x0=x;
    %% 
    [~,S]=min(x); 
    flag=zeros(1,data.numNode);
    flag(S)=1;
    path=[S];
    sumD=0;
    for i=1:data.numNode-1
       position=find(flag==0);
       D=data.D(S,position);
       pri=x(position);
       [~,no]=min(D.*pri);
       next=position(no);
       flag(next)=1;
       path=[path,next];
       S=next;
       sumD=sumD+D(no);
    end
    sumD=sumD+data.D(S,path(1));
    path=[path,path(1)];
    fit=sumD;
    %%
    if nargout>1
        result.path=path; %·��
        result.fit=fit;    %�ܾ���
    end
end