function x=creat_x(option,data)
    x=rand(1,option.dim);
end