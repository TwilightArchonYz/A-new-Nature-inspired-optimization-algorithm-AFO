
function  [V,F] = DrawCuboid(long, wide, pretty, x,y,z)
% Input:long wide pretty (position: x,y)
% long = 200; wide = 150; pretty = 5; x = 20; y =20;
V = [x y z; x+long y z; x y+wide z; x+long y+wide z; x y z+pretty; x+long y z+pretty; x y+wide z+pretty; x+long y+wide z+pretty];
F = [1  2  4  3; 5  6  8  7; 1  2  6  5; 3  4  8  7; 1  5  7  3; 2  6  8  4]; 
C = [210 250 250 ]/255;  % ��ɫ

patch('Vertices',V,'Faces',F,...
    'FaceVertexCData',C,...
    'FaceColor','flat');

end


