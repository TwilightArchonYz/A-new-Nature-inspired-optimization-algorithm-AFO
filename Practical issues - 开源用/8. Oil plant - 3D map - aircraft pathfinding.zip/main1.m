%% 2021.9.2 ʯ�ͳ���-��ά��ͼ-���˻�Ѱ·
% 2021.9.2 Oil plant - 3D map - aircraft pathfinding
%% ����ʹ��ԭʼ�㷨��ֱ�������������ר���ڱ�����ĸ��·�ʽ���Խ�һ����߾���
% This is the direct result of using the original algorithm, 
% adding some specific update methods to this problem can further improve the accuracy
clc;
clear;
close all;
warning off
%% �̶����������
noRNG=1;
rng('default')
rng(noRNG)
%% ��������
data.S=[1,950,12];     %���λ��
data.E=[950,1,1]; %�յ��λ��
data.Obstacle=xlsread('data1.xls');
data.numObstacles=length(data.Obstacle(:,1));
data.mapSize=[1000,1000,20]; %10m ��ͼ�ߴ�
data.unit=[50,50,1]; %��ͼ����
data.S0=ceil(data.S./data.unit);
data.E0=ceil(data.E./data.unit);
data.mapSize0=data.mapSize./data.unit;
data.map=zeros(data.mapSize0);
figure
plot3(data.S(:,1),data.S(:,2),data.S(:,3),'o','LineWidth',2,...
                     'MarkerEdgeColor','k',...
                     'MarkerFaceColor','r',...
                     'MarkerSize',10)
hold on
plot3(data.E(:,1),data.E(:,2),data.E(:,3),'h','LineWidth',2,...
                     'MarkerEdgeColor','k',...
                     'MarkerFaceColor','r',...
                     'MarkerSize',10)
for i=1:data.numObstacles
    x=1+data.Obstacle(i,1);
    y=1+data.Obstacle(i,2);
    z=1+data.Obstacle(i,3);
    long=data.Obstacle(i,4);
    wide=data.Obstacle(i,5);
    pretty=data.Obstacle(i,6);
    [V,F] = DrawCuboid(long, wide, pretty, x,y,z);
    x0=ceil(x/data.unit(1));
    y0=ceil(y/data.unit(2));
    z0=ceil(z/data.unit(3));
    long0=ceil(long/data.unit(1));
    wide0=ceil(wide/data.unit(2));
    pretty0=ceil(pretty/data.unit(3));
    data.map(x0:x0+long0,y0:y0+wide0,z0:z0+pretty0)=1;
end
legend('���','�յ�')
title('��ά���ε�ͼ')
grid on
axis equal
%%
index=find(data.map==1);
[p1,p2,p3] = ind2sub(size(data.map), index);
figure
plot3(data.S0(:,1),data.S0(:,2),data.S0(:,3),'o','LineWidth',2,...
                     'MarkerEdgeColor','k',...
                     'MarkerFaceColor','r',...
                     'MarkerSize',10)
hold on
plot3(data.E0(:,1),data.E0(:,2),data.E0(:,3),'h','LineWidth',2,...
                     'MarkerEdgeColor','k',...
                     'MarkerFaceColor','r',...
                     'MarkerSize',10)
plot3(p1,p2,p3,'.','LineWidth',2,...
                     'MarkerEdgeColor','k',...
                     'MarkerFaceColor','r',...
                     'MarkerSize',10)
legend('���','�յ�')
title('��ά���ε�ͼ')
grid on
axis equal
xlabel('x��km��')
ylabel('y��km��')
zlabel('z��km��')
%% ���ɿ��ƶ�����
temp=[1,0,-1];
direction=[];
for i=1:3
    for j=1:3
        for k=1:3
            direction=[direction;temp(i),temp(j),temp(k)];
        end
    end
end
position=find(direction(:,1)==0 & direction(:,2)==0 & direction(:,3)==0);
direction(position,:)=[];
data.direction=direction;
%%
dim=prod(data.mapSize0);
%%
option.dim=dim;
lb=0;
ub=1;
option.lb=lb;
option.ub=ub;
if length(option.lb)==1
    option.lb=ones(1,option.dim)*option.lb;
    option.ub=ones(1,option.dim)*option.ub;
end
option.fobj=@aimFcn_1;
%option.fobj0=option.fobj;
option.showIter=0;
%% �㷨�������� Parameters
% ��������
option.numAgent=200;        %��Ⱥ������ size of population
option.maxIteration=200;    %���������� maximum number of interation
% ������㷨
option.v_lb=-(option.ub-option.lb)/4;
option.v_ub=(option.ub-option.lb)/4;
option.w2=0.5; %weight of Moving strategy III
option.w4=1;%weight of Moving strategy III
option.w5=1;%weight of Moving strategy III
option.pe=0.01; % rate to judge Premature convergence
option.gap0=ceil(sqrt(option.maxIteration*2))+1;
option.gapMin=5; % min gap
option.dec=2;    % dec of gap
option.L=10;     % Catastrophe
str_legend=[{'AFO1'},{'AFO2'}];
%% Initialize population individuals (common to control experiment algorithm)
x=ones(option.numAgent,option.dim);
y=ones(option.numAgent,1);
for i=1:option.numAgent
    x(i,:)=rand(size(option.lb)).*(option.ub-option.lb)+option.lb;
    y(i)=option.fobj(x(i,:),option,data);
end
%% ʹ���㷨���
% Based on the same population, solve the selected  functions by using different algorithms
bestX=x;
rng(noRNG)
tic
[bestY(1,:),bestX(1,:),recording(1)]=AFO1(x,y,option,data);
tt(1,1)=toc;
rng(noRNG)
tic
[bestY(2,:),bestX(2,:),recording(2)]=AFO2(x,y,option,data);
tt(1,2)=toc;
%%
figure
hold on
for i=1:length(recording)
    plot((recording(i).bestFit),'LineWidth',2)
end
legend(str_legend)
title('fitness curve')

%% ������
str='AFO1'
[~,result1]=option.fobj(bestX(1,:),option,data);
drawPc(result1,option,data,str)
str='AFO2'
[~,result2]=option.fobj(bestX(2,:),option,data);
drawPc(result1,option,data,str)