function [fit,result]=aimFcn_1(x,option,data,net0)
%% ��Ŀ�꺯������������������
input_train=data.train_x;
output_train=data.train_y;
input_test=data.test_x;
for i=1:length(data.len) 
    temp=x(1:data.len(i));
    x(1:data.len(i))=[];
    mat{i}=reshape(temp,data.m(i),data.n(i));
end
%����Ȩֵ��ֵ
net=net0;
no=1;
for i=1:data.m_iw
    for j=1:data.n_iw
        net0.iw{i,j}=mat{no};
        no=no+1;
    end
end
for i=1:data.m_lw
    for j=1:data.n_lw
        net0.lw{i,j}=mat{no};
        no=no+1;
    end
end
for i=1:data.m_b
    for j=1:data.n_b
        net0.b{i,j}=mat{no};
        no=no+1;
    end
end
net.trainParam.showWindow = false; % ����ʾѵ������
net.trainParam.showCommandLine = false;% �����в���ʾ���
[net,tr]=train(net,input_train',output_train');
ygabptest=sim(net,input_test');
for i=1:length(ygabptest(:,1))
    result.mse(i)=mse(ygabptest(i,:)-data.test_y(:,i)');
end
result.net=net;
fit=sum(data.weight.*result.mse);
result.fit=fit;
result.n=data.n;
result.m=data.m;
result.len=data.len;
result.n_lw=data.n_lw;
result.m_lw=data.m_lw;
result.n_iw=data.n_iw;
result.m_iw=data.m_iw;
result.n_b=data.n_b;
result.m_b=data.m_b;
result.ygabptest=ygabptest;
end