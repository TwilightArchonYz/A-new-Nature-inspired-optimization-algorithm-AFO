function x=test_x(x,option,data)
    for i=1:length(option.bound(:,2))
        if x(i)<option.bound(i,1)
            x(i)=option.bound(i,1);
        end
        if x(i)>option.bound(i,2)
            x(i)=option.bound(i,2);
        end
    end
    x(end)=round(x(end));
end