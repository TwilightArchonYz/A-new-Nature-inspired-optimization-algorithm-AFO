function [x,result]=creat_x_1(option,data)
hiddenumber=data.hiddenumber;
input_train=data.train_x;
output_train=data.train_y;
input_test=data.test_x;
%�½�bp������
TF1 = 'purelin';
TF2 = 'purelin';
TF3 = 'tansig';
net0=newff(input_train',output_train',hiddenumber,{TF1 TF2 TF3}, 'trainlm' );
%net0 = newff([-1 1;-1 1;-1 1;-1 1;-1 1;-1 1;-1 1;-1 1;-1,1], [8 4], {'logsig' 'purelin' } , 'trainlm' ) ;
%net0.trainFcn='traingd';
net0.trainparam.show = 50 ;  %ÿ���50����ʾһ��ѵ�����
net0.trainparam.epochs =100; %�������ѵ������3300��
net0.trainparam.goal = 0.000000001;  %ѵ��Ŀ����С���0.000001 
net0.trainParam.lr = 0.01 ; %ѧϰ����0.01
net0.trainParam.min_grad=0.000000000001;% ��С�����ݶ�
%     net0.trainParam.showWindow = false; % ����ʾѵ������
%     net0.trainParam.showCommandLine = false;% �����в���ʾ���


[net0,tr]=train(net0,input_train',output_train');
ybptrain=sim(net0,input_train');
ybptest=sim(net0,input_test');

%�ܽڵ�������
% ��ֵ
x0=[];
[m_lw,n_lw]=size(net0.lw);
[m_iw,n_iw]=size(net0.iw);
no=1;
for i=1:m_iw
    for j=1:n_iw
        mat{no}=net0.iw{i,j};
        no=no+1;
    end
end
for i=1:m_lw
    for j=1:n_lw
        mat{no}=net0.lw{i,j};
        no=no+1;
    end
end
[m_b,n_b]=size(net0.b);
for i=1:m_b
    for j=1:n_b
        mat{no}=net0.b{i,j};
        no=no+1;
    end
end
for i=1:length(mat)
    [m(i),n(i)]=size(mat{i});
    len(i)=m(i)*n(i);
    x0=[x0;reshape(mat{i},len(i),1)];
end
x=mean(mean(x0))*randn(size(x0))*0.01+x0;
%x=x0;
result.net=net0;
result.n=n;
result.m=m;
result.n_lw=n_lw;
result.m_lw=m_lw;
result.n_iw=n_iw;
result.m_iw=m_iw;
result.n_b=n_b;
result.m_b=m_b;
result.len=len;
net=net0;
ygabptest=sim(net,input_test');
for i=1:length(ygabptest(:,1))
    result.mse(i)=mse(ygabptest(i,:)-data.test_y(:,i)');
end
result.net=net;
fit=sum(data.weight.*result.mse);
result.fit=fit;
ygabptest=sim(net0,input_test');
for i=1:length(ygabptest(:,1))
    result.mse(i)=mse(ygabptest(i,:)-data.test_y(:,i)');
end
result.ygabptest=ygabptest;
%     %%
%     ygabptest=sim(net0,input_test');
%     ygabptest=mapminmax('reverse',ygabptest,option.ps_y);%Ԥ�����ݷ���һ��
%     T2=mapminmax('reverse',data.test_y,option.ps_y);%Ԥ�����ݷ���һ��
%     fit=sum((abs(ygabptest'-T2)./T2).^2);
%     result.net=net0;
%     result.ygabptest=ygabptest';
%     result.T2=T2;
%
%     ygabptrain=sim(net0,input_train');
%     ygabptrain=mapminmax('reverse',ygabptrain,option.ps_y);%Ԥ�����ݷ���һ��
%     T1=mapminmax('reverse',data.train_y,option.ps_y);%Ԥ�����ݷ���һ��
%     result.ygabptrain=ygabptrain';
%     result.T1=T1;
end