%% 2021.9.2 帝企鹅算法：TSP问题
% 2021.9.2 AFO TSP problems
%% 同起点 数量不固定
% TSP issues with same starting points and a unfixed number of
% travellers (The number of travel agents can be less than the preset value)
%% 这是使用原始算法的直接求解结果，添加专用于本问题的更新方式可以进一步提高精度
% This is the direct result of using the original algorithm, 
% adding some specific update methods to this problem can further improve the accuracy
clc;
clear;
close all;
warning off
%% 固定随机数种子
noRNG=1;
rng('default')
rng(noRNG)
%% 载入数据
data.maxTraveler=3; %最大旅行商数量
data.numCity=30; %城市数量
%% 随机生成城市
data.xyCity=rand(data.numCity,2);
for i=1:data.numCity
    for j=1:data.numCity
        data.D(i,j)=norm(data.xyCity(i,:)-data.xyCity(j,:));
    end
end
%%
option.dim=data.numCity+1;
lb=0;
ub=1;
option.lb=lb;
option.ub=ub;
if length(option.lb)==1
    option.lb=ones(1,option.dim)*option.lb;
    option.ub=ones(1,option.dim)*option.ub;
end
option.fobj=@aimFcn_3;
option.showIter=0;
%% 算法参数设置 Parameters
% 基本参数
option.numAgent=200;        %种群个体数 size of population
option.maxIteration=100;    %最大迭代次数 maximum number of interation
% 帝企鹅算法
option.v_lb=-(option.ub-option.lb)/4;
option.v_ub=(option.ub-option.lb)/4;
option.w2=0.5; %weight of Moving strategy III
option.w4=1;%weight of Moving strategy III
option.w5=1;%weight of Moving strategy III
option.pe=0.01; % rate to judge Premature convergence
option.gap0=ceil(sqrt(option.maxIteration*2))+1;
option.gapMin=5; % min gap
option.dec=2;    % dec of gap
option.L=10;     % Catastrophe
str_legend=[{'AFO1'},{'AFO2'}];
%% Initialize population individuals (common to control experiment algorithm)
x=ones(option.numAgent,option.dim);
y=ones(option.numAgent,1);
for i=1:option.numAgent
    x(i,:)=rand(size(option.lb)).*(option.ub-option.lb)+option.lb;
    y(i)=option.fobj(x(i,:),option,data);
end
%% 使用算法求解
% Based on the same population, solve the selected  functions by using different algorithms
bestX=x;
rng(noRNG)
tic
[bestY(1,:),bestX(1,:),recording(1)]=AFO1(x,y,option,data);
tt(1,1)=toc;
rng(noRNG)
tic
[bestY(2,:),bestX(2,:),recording(2)]=AFO2(x,y,option,data);
tt(1,2)=toc;
%%
figure
hold on
for i=1:length(recording)
    plot((recording(i).bestFit),'LineWidth',2)
end
legend(str_legend)
title('fitness curve')

%% 输出结果
str='AFO1'
[~,result1]=option.fobj(bestX(1,:),option,data);
drawPc(result1,option,data,str)
str='AFO2'
[~,result2]=option.fobj(bestX(2,:),option,data);
drawPc(result2,option,data,str)