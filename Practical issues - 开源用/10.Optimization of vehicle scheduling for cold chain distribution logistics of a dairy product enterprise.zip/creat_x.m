function x=creat_x(option,data)
    jishu=1;
    flag=zeros(1,data.numNode);
    flag(1)=1;
    no1=1;
    path=[];
    for i=1:data.numNode-1
       position=find(flag==0);
       tempD=data.D(no1,position);
       [~,S]=sort(tempD+0.05*randn(size(tempD))*mean(tempD));
    %   [~,S]=sort(tempD);
       S=position(S);
       path=[path,S(1)-1];
       flag(S(1))=1;
       if rem(i,ceil(data.numNode/data.maxV))==0 && jishu<=data.maxV-1
           no1=1;
           path=[path,jishu+data.numNode-1];
           jishu=jishu+1;
       else
           no1=S(1);
       end
    end
    while jishu<=data.maxV-1
        path=[path,jishu+data.numNode-1];
        jishu=jishu+1;
    end
    temp=rand(1,option.dim);
    temp=sort(temp);
    for i=1:option.dim
        try
        x(path(i))=temp(i);
        catch
            a=1;
        end
    end
    length(x)
    if length(x)~=option.dim
        a=1;
    end
end