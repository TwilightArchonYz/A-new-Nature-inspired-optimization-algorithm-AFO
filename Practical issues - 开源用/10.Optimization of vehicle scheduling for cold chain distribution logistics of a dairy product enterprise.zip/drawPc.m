function drawPc(result1,option,data,str)
    figure
    hold on
    legendStr=[{'����'},{'�˿�'}];
    plot(data.node(data.noCenter,2),data.node(data.noCenter,3),'h','LineWidth',2,...
        'MarkerEdgeColor','k',...
        'MarkerFaceColor','r',...
        'MarkerSize',10);
    plot(data.node(data.noNode,2),data.node(data.noNode,3),'o','LineWidth',2,...
        'MarkerEdgeColor','k',...
        'MarkerFaceColor','g',...
        'MarkerSize',10);
    for i=1:length(result1.recording.Path)
        path=[result1.recording.Path{i}(:,1);1];
        plot(data.node(path,2),data.node(path,3),'-','LineWidth',2);
        legendStr=[legendStr,{['��',num2str(i),'����·��']}];
    end
    legend(legendStr);
    title([str,'�����·�ߣ���Ŀ�꣺',num2str(result1.fit)]);
    for i=1:length(result1.recording.Path)
        figure
        hold on
        legendStr=[{'����'},{'�˿�'}];
        plot(data.node(data.noCenter,2),data.node(data.noCenter,3),'h','LineWidth',2,...
            'MarkerEdgeColor','k',...
            'MarkerFaceColor','r',...
            'MarkerSize',10);
        plot(data.node(data.noNode,2),data.node(data.noNode,3),'o','LineWidth',2,...
            'MarkerEdgeColor','k',...
            'MarkerFaceColor','g',...
            'MarkerSize',10);
        
        path=[result1.recording.Path{i}(:,1);1];
        plot(data.node(path,2),data.node(path,3),'-','LineWidth',2);
        legendStr=[legendStr,{['��',num2str(i),'����·��']}];
        legend(legendStr);
        title([str,'����',num2str(i),'����·�ߣ���Ŀ�꣺',num2str(result1.fit)]);
    end

end